#if UNITY_EDITOR
using System.Collections.Generic;
using AyutthayaSimulator.ShophouseDestructible;
using UnityEditor;
using UnityEngine;
using UnityEngine.Rendering;

public static class ShophouseDestructibleGenerator
{
    private const string PackageRoot = "Assets/ShophouseDestructibleV1";
    private const string GeneratedRoot = PackageRoot + "/Generated";
    private static Material _wallMat, _trimMat, _metalMat, _glassMat, _awningMat, _floorMat, _emissiveMat;

    [MenuItem("Tools/AYUTTHAYA/Generate Destructible Shophouse V1")]
    public static void Generate()
    {
        EnsureFolders();
        BuildMaterials();

        GameObject root = new GameObject("DestructibleShophouse_V1");
        Undo.RegisterCreatedObjectUndo(root, "Generate Destructible Shophouse V1");

        root.transform.position = Vector3.zero;

        CreateGround(root.transform);
        CreateLodStructure(root.transform);

        var controller = root.AddComponent<ShophouseDestructionController>();
        controller.breakableSections = root.GetComponentsInChildren<BreakableSection>(true);

        Selection.activeGameObject = root;
        EditorGUIUtility.PingObject(root);
        Debug.Log("Destructible Shophouse V1 generated.");
    }

    private static void EnsureFolders()
    {
        CreateFolderIfMissing("Assets", "ShophouseDestructibleV1");
        CreateFolderIfMissing(PackageRoot, "Generated");
        CreateFolderIfMissing(GeneratedRoot, "Materials");
    }

    private static void BuildMaterials()
    {
        Shader lit = Shader.Find("Universal Render Pipeline/Lit");
        if (lit == null) lit = Shader.Find("Standard");

        Texture2D baseColor = AssetDatabase.LoadAssetAtPath<Texture2D>(PackageRoot + "/Textures/BaseColor.png");
        Texture2D normal = AssetDatabase.LoadAssetAtPath<Texture2D>(PackageRoot + "/Textures/Normal.png");
        Texture2D roughness = AssetDatabase.LoadAssetAtPath<Texture2D>(PackageRoot + "/Textures/Roughness.png");
        Texture2D metallic = AssetDatabase.LoadAssetAtPath<Texture2D>(PackageRoot + "/Textures/Metallic.png");
        Texture2D ao = AssetDatabase.LoadAssetAtPath<Texture2D>(PackageRoot + "/Textures/AO.png");
        Texture2D emissive = AssetDatabase.LoadAssetAtPath<Texture2D>(PackageRoot + "/Textures/Emissive.png");

        _wallMat = CreatePbrMaterial(lit, "MAT_Wall", baseColor, normal, metallic, ao, new Color(0.96f, 0.93f, 0.87f), 0.1f, 0.75f);
        _trimMat = CreateSimpleMaterial(lit, "MAT_Trim", new Color(0.88f, 0.84f, 0.78f), 0.0f, 0.7f);
        _metalMat = CreatePbrMaterial(lit, "MAT_Metal", baseColor, normal, metallic, ao, new Color(0.30f, 0.30f, 0.32f), 0.55f, 0.35f);
        _glassMat = CreateTransparentMaterial(lit, "MAT_Glass", new Color(0.55f, 0.7f, 0.85f, 0.2f));
        _awningMat = CreateSimpleMaterial(lit, "MAT_Awning", new Color(0.82f, 0.86f, 0.90f), 0f, 0.65f);
        _floorMat = CreateSimpleMaterial(lit, "MAT_Floor", new Color(0.70f, 0.70f, 0.70f), 0f, 0.55f);
        _emissiveMat = CreateEmissiveMaterial(lit, "MAT_Emissive", emissive, new Color(1.0f, 0.95f, 0.8f));
    }

    private static Material CreatePbrMaterial(Shader shader, string name, Texture2D baseMap, Texture2D normal, Texture2D metallic, Texture2D ao, Color tint, float metallicValue, float smoothness)
    {
        string path = GeneratedRoot + "/Materials/" + name + ".mat";
        Material mat = AssetDatabase.LoadAssetAtPath<Material>(path);
        if (mat == null)
        {
            mat = new Material(shader);
            AssetDatabase.CreateAsset(mat, path);
        }

        SetupColor(mat, tint);
        SetupBaseMap(mat, baseMap);
        SetupNormal(mat, normal);
        SetupMetallic(mat, metallic, metallicValue, smoothness);
        SetupOcclusion(mat, ao);
        EditorUtility.SetDirty(mat);
        return mat;
    }

    private static Material CreateSimpleMaterial(Shader shader, string name, Color tint, float metallicValue, float smoothness)
    {
        string path = GeneratedRoot + "/Materials/" + name + ".mat";
        Material mat = AssetDatabase.LoadAssetAtPath<Material>(path);
        if (mat == null)
        {
            mat = new Material(shader);
            AssetDatabase.CreateAsset(mat, path);
        }
        SetupColor(mat, tint);
        SetupMetallic(mat, null, metallicValue, smoothness);
        EditorUtility.SetDirty(mat);
        return mat;
    }

    private static Material CreateTransparentMaterial(Shader shader, string name, Color tint)
    {
        string path = GeneratedRoot + "/Materials/" + name + ".mat";
        Material mat = AssetDatabase.LoadAssetAtPath<Material>(path);
        if (mat == null)
        {
            mat = new Material(shader);
            AssetDatabase.CreateAsset(mat, path);
        }
        SetupColor(mat, tint);
        if (mat.HasProperty("_Surface")) mat.SetFloat("_Surface", 1f);
        if (mat.HasProperty("_Blend")) mat.SetFloat("_Blend", 0f);
        if (mat.HasProperty("_AlphaClip")) mat.SetFloat("_AlphaClip", 0f);
        if (mat.HasProperty("_SrcBlend")) mat.SetFloat("_SrcBlend", (float)BlendMode.SrcAlpha);
        if (mat.HasProperty("_DstBlend")) mat.SetFloat("_DstBlend", (float)BlendMode.OneMinusSrcAlpha);
        if (mat.HasProperty("_ZWrite")) mat.SetFloat("_ZWrite", 0f);
        mat.renderQueue = (int)RenderQueue.Transparent;
        EditorUtility.SetDirty(mat);
        return mat;
    }

    private static Material CreateEmissiveMaterial(Shader shader, string name, Texture2D emissiveMap, Color emissiveColor)
    {
        string path = GeneratedRoot + "/Materials/" + name + ".mat";
        Material mat = AssetDatabase.LoadAssetAtPath<Material>(path);
        if (mat == null)
        {
            mat = new Material(shader);
            AssetDatabase.CreateAsset(mat, path);
        }
        SetupColor(mat, Color.white);
        if (mat.HasProperty("_BaseMap")) mat.SetTexture("_BaseMap", emissiveMap);
        if (mat.HasProperty("_MainTex")) mat.SetTexture("_MainTex", emissiveMap);
        if (mat.HasProperty("_EmissionColor")) mat.SetColor("_EmissionColor", emissiveColor * 2f);
        if (mat.HasProperty("_EmissionMap")) mat.SetTexture("_EmissionMap", emissiveMap);
        mat.EnableKeyword("_EMISSION");
        EditorUtility.SetDirty(mat);
        return mat;
    }

    private static void SetupColor(Material mat, Color color)
    {
        if (mat.HasProperty("_BaseColor")) mat.SetColor("_BaseColor", color);
        if (mat.HasProperty("_Color")) mat.SetColor("_Color", color);
    }

    private static void SetupBaseMap(Material mat, Texture2D tex)
    {
        if (tex == null) return;
        if (mat.HasProperty("_BaseMap")) mat.SetTexture("_BaseMap", tex);
        if (mat.HasProperty("_MainTex")) mat.SetTexture("_MainTex", tex);
    }

    private static void SetupNormal(Material mat, Texture2D tex)
    {
        if (tex == null) return;
        if (mat.HasProperty("_BumpMap"))
        {
            mat.EnableKeyword("_NORMALMAP");
            mat.SetTexture("_BumpMap", tex);
        }
    }

    private static void SetupMetallic(Material mat, Texture2D tex, float metallicValue, float smoothness)
    {
        if (mat.HasProperty("_Metallic")) mat.SetFloat("_Metallic", metallicValue);
        if (mat.HasProperty("_Glossiness")) mat.SetFloat("_Glossiness", smoothness);
        if (mat.HasProperty("_Smoothness")) mat.SetFloat("_Smoothness", smoothness);
        if (tex != null && mat.HasProperty("_MetallicGlossMap"))
        {
            mat.SetTexture("_MetallicGlossMap", tex);
            mat.EnableKeyword("_METALLICSPECGLOSSMAP");
        }
    }

    private static void SetupOcclusion(Material mat, Texture2D tex)
    {
        if (tex == null) return;
        if (mat.HasProperty("_OcclusionMap")) mat.SetTexture("_OcclusionMap", tex);
    }

    private static void CreateGround(Transform root)
    {
        GameObject ground = CreateCube("Ground", root, new Vector3(18f, 0.15f, 12f), new Vector3(0f, -0.075f, 0f), _floorMat);
        Object.DestroyImmediate(ground.GetComponent<BoxCollider>());
        ground.AddComponent<BoxCollider>();
        CreateCube("Sidewalk", root, new Vector3(17.5f, 0.12f, 1.8f), new Vector3(0f, 0.06f, 4.3f), _floorMat);
        CreateCube("Curb", root, new Vector3(17.8f, 0.18f, 0.22f), new Vector3(0f, 0.09f, 5.15f), _trimMat);
    }

    private static void CreateLodStructure(Transform root)
    {
        GameObject lodRoot = new GameObject("LOD_Root");
        lodRoot.transform.SetParent(root, false);

        GameObject lod0 = new GameObject("LOD0"); lod0.transform.SetParent(lodRoot.transform, false);
        GameObject lod1 = new GameObject("LOD1"); lod1.transform.SetParent(lodRoot.transform, false);
        GameObject lod2 = new GameObject("LOD2"); lod2.transform.SetParent(lodRoot.transform, false);

        BuildLod0(lod0.transform, true);
        BuildLod1(lod1.transform);
        BuildLod2(lod2.transform);

        var group = lodRoot.AddComponent<LODGroup>();
        var r0 = lod0.GetComponentsInChildren<Renderer>();
        var r1 = lod1.GetComponentsInChildren<Renderer>();
        var r2 = lod2.GetComponentsInChildren<Renderer>();
        group.SetLODs(new []
        {
            new LOD(0.55f, r0),
            new LOD(0.22f, r1),
            new LOD(0.05f, r2)
        });
        group.RecalculateBounds();
        lod1.SetActive(false);
        lod2.SetActive(false);
    }

    private static void BuildLod0(Transform root, bool withInteriors)
    {
        const float width = 12f;
        const float depth = 10f;
        const float height = 10.2f;
        const float floorH = 3.3f;
        const float bay = width / 3f;

        // structural shell
        for (int f = 0; f < 3; f++)
        {
            float yFloor = f * floorH;
            CreateCube($"Floor_{f+1}", root, new Vector3(width, 0.18f, depth), new Vector3(0f, yFloor, 0f), _floorMat);
        }
        CreateCube("RoofSlab", root, new Vector3(width, 0.25f, depth), new Vector3(0f, 3 * floorH, 0f), _trimMat);

        // columns front and back
        float[] xs = { -width/2f + 0.25f, -bay/2f, bay/2f, width/2f - 0.25f };
        foreach (float x in xs)
        {
            CreateCube($"FrontCol_{x:F2}", root, new Vector3(0.35f, height, 0.35f), new Vector3(x, height/2f, depth/2f - 0.18f), _trimMat);
            CreateCube($"BackCol_{x:F2}", root, new Vector3(0.30f, height, 0.30f), new Vector3(x, height/2f, -depth/2f + 0.18f), _trimMat);
        }

        // side / back walls
        CreateCube("LeftWall", root, new Vector3(0.25f, height, depth), new Vector3(-width/2f + 0.125f, height/2f, 0f), _wallMat);
        CreateCube("RightWall", root, new Vector3(0.25f, height, depth), new Vector3(width/2f - 0.125f, height/2f, 0f), _wallMat);
        CreateCube("BackWall", root, new Vector3(width, height, 0.25f), new Vector3(0f, height/2f, -depth/2f + 0.125f), _wallMat);

        // interior stair core right side
        CreateStairs(root, new Vector3(width/2f - 1.4f, 0.0f, 2.2f), floorH, 2.2f, 2.6f);
        CreateStairs(root, new Vector3(width/2f - 1.4f, floorH, 0.4f), floorH, 2.2f, -2.6f);

        // front façade by floor
        CreateGroundFloorFacade(root, bay, depth);
        CreateUpperFloorFacade(root, 1, bay, depth);
        CreateUpperFloorFacade(root, 2, bay, depth);

        // roof parapet and electrical poles hint
        CreateCube("Parapet", root, new Vector3(width, 0.8f, 0.25f), new Vector3(0f, height + 0.4f, depth/2f - 0.05f), _trimMat);
        CreateCube("RoofSignBand", root, new Vector3(width, 0.35f, 0.12f), new Vector3(0f, height + 0.15f, depth/2f + 0.05f), _trimMat);
        CreateLamp(root, new Vector3(-3.5f, 3.0f, 4.75f));
        CreateLamp(root, new Vector3(0f, 3.0f, 4.75f));
        CreateLamp(root, new Vector3(3.5f, 3.0f, 4.75f));

        if (withInteriors)
        {
            CreateInterior(root, bay, depth, floorH);
        }
    }

    private static void CreateGroundFloorFacade(Transform root, float bay, float depth)
    {
        float z = depth / 2f - 0.05f;

        // Left shutter shop
        CreateBreakablePanel(root, "GF_LeftWall", new Vector3(bay, 3.1f, 0.18f), new Vector3(-bay, 1.65f, z), _wallMat, new Vector3Int(2,2,1));
        CreateShutter(root, "LeftShutter", new Vector3(-bay, 1.55f, z + 0.06f), 3.0f, 2.45f);

        // Center entrance
        CreateBreakablePanel(root, "GF_CenterWall", new Vector3(bay, 3.1f, 0.18f), new Vector3(0f, 1.65f, z), _wallMat, new Vector3Int(2,2,1));
        CreateGlassEntrance(root, new Vector3(0f, 1.25f, z + 0.06f), 2.35f, 2.45f);

        // Right shutter shop
        CreateBreakablePanel(root, "GF_RightWall", new Vector3(bay, 3.1f, 0.18f), new Vector3(bay, 1.65f, z), _wallMat, new Vector3Int(2,2,1));
        CreateShutter(root, "RightShutter", new Vector3(bay, 1.55f, z + 0.06f), 3.0f, 2.45f);

        CreateAwning(root);
    }

    private static void CreateUpperFloorFacade(Transform root, int level, float bay, float depth)
    {
        float floorH = 3.3f;
        float yBase = level * floorH;
        float z = depth / 2f - 0.06f;

        for (int i = 0; i < 3; i++)
        {
            float x = (-bay) + i * bay;
            CreateBreakablePanel(root, $"UF{level}_{i}_Wall", new Vector3(bay, 2.9f, 0.18f), new Vector3(x, yBase + 1.55f, z), _wallMat, new Vector3Int(2,2,1));
            CreateWindow(root, $"Window_L{level}_{i}", new Vector3(x, yBase + 2.15f, z + 0.04f), 2.55f, 1.4f);
            CreateBalcony(root, new Vector3(x, yBase + 1.08f, z + 0.35f), 2.6f, 0.45f);
        }
    }

    private static void CreateInterior(Transform root, float bay, float depth, float floorH)
    {
        // simple room divisions and props
        for (int f = 0; f < 3; f++)
        {
            float y = f * floorH + 0.1f;
            CreateCube($"BackRoomWall_{f}", root, new Vector3(0.12f, 2.7f, 4.5f), new Vector3(1.7f, y + 1.35f, -1.5f), _trimMat);
            CreateShelf(root, new Vector3(-2.6f, y + 0.9f, -3.2f));
            CreateDesk(root, new Vector3(0.5f, y + 0.45f, -1.8f));
            CreateLampPlane(root, new Vector3(0f, y + 2.9f, 0f));
        }
    }

    private static void CreateStairs(Transform root, Vector3 start, float rise, float run, float zDir)
    {
        int steps = 10;
        float stepH = rise / steps;
        float stepD = Mathf.Abs(run) / steps;
        float dir = Mathf.Sign(zDir);
        for (int i = 0; i < steps; i++)
        {
            CreateCube($"Stair_{start.y}_{i}", root, new Vector3(1.5f, stepH, stepD), new Vector3(start.x, start.y + stepH * (i + 0.5f), start.z + dir * stepD * (i + 0.5f)), _floorMat);
        }
        CreateCube("Landing", root, new Vector3(1.6f, 0.12f, 1.6f), new Vector3(start.x, start.y + rise, start.z + zDir), _floorMat);
    }

    private static void CreateShutter(Transform root, string name, Vector3 pos, float width, float height)
    {
        GameObject shutter = CreateCube(name, root, new Vector3(width, height, 0.05f), pos, _metalMat);
        var openable = shutter.AddComponent<OpenablePart>();
        openable.openMode = OpenablePart.OpenMode.Slide;
        openable.axis = OpenablePart.Axis.Y;
        openable.openDistance = height * 0.78f;
        openable.speed = 1.4f;
        openable.prompt = "E เปิด/ปิดประตูม้วน";
    }

    private static void CreateGlassEntrance(Transform root, Vector3 pos, float width, float height)
    {
        GameObject frame = CreateCube("DoorFrameTop", root, new Vector3(width, 0.1f, 0.08f), pos + new Vector3(0f, height/2f, 0f), _trimMat);
        CreateCube("DoorFrameL", root, new Vector3(0.08f, height, 0.08f), pos + new Vector3(-width/2f, 0f, 0f), _trimMat);
        CreateCube("DoorFrameR", root, new Vector3(0.08f, height, 0.08f), pos + new Vector3(width/2f, 0f, 0f), _trimMat);
        CreateCube("DoorTransom", root, new Vector3(width, 0.48f, 0.04f), pos + new Vector3(0f, height/2f - 0.3f, 0.02f), _glassMat);

        float leafW = width / 2f - 0.05f;
        GameObject left = CreateCube("DoorLeaf_L", root, new Vector3(leafW, height - 0.55f, 0.04f), pos + new Vector3(-leafW/2f, -0.25f, 0.02f), _glassMat);
        GameObject right = CreateCube("DoorLeaf_R", root, new Vector3(leafW, height - 0.55f, 0.04f), pos + new Vector3(leafW/2f, -0.25f, 0.02f), _glassMat);
        var ol = left.AddComponent<OpenablePart>();
        ol.openMode = OpenablePart.OpenMode.Slide; ol.axis = OpenablePart.Axis.X; ol.openDistance = -leafW*0.85f; ol.prompt = "E เปิด/ปิดประตูกระจก"; ol.invertDirection = false;
        var or = right.AddComponent<OpenablePart>();
        or.openMode = OpenablePart.OpenMode.Slide; or.axis = OpenablePart.Axis.X; or.openDistance = leafW*0.85f; or.prompt = "E เปิด/ปิดประตูกระจก";
    }

    private static void CreateWindow(Transform root, string name, Vector3 pos, float width, float height)
    {
        CreateCube(name + "_Top", root, new Vector3(width, 0.08f, 0.05f), pos + new Vector3(0f, height/2f, 0f), _metalMat);
        CreateCube(name + "_Bottom", root, new Vector3(width, 0.08f, 0.05f), pos + new Vector3(0f, -height/2f, 0f), _metalMat);
        CreateCube(name + "_Left", root, new Vector3(0.08f, height, 0.05f), pos + new Vector3(-width/2f, 0f, 0f), _metalMat);
        CreateCube(name + "_Right", root, new Vector3(0.08f, height, 0.05f), pos + new Vector3(width/2f, 0f, 0f), _metalMat);
        CreateCube(name + "_Mullion", root, new Vector3(0.06f, height, 0.04f), pos, _metalMat);
        CreateCube(name + "_GlassL", root, new Vector3(width/2f - 0.1f, height - 0.1f, 0.03f), pos + new Vector3(-width/4f, 0f, 0.01f), _glassMat);
        CreateCube(name + "_GlassR", root, new Vector3(width/2f - 0.1f, height - 0.1f, 0.03f), pos + new Vector3(width/4f, 0f, 0.01f), _glassMat);
    }

    private static void CreateBalcony(Transform root, Vector3 pos, float width, float depth)
    {
        CreateCube("BalconySlab", root, new Vector3(width, 0.08f, depth), pos + new Vector3(0f, -0.42f, 0f), _floorMat);
        CreateCube("BalconyRailTop", root, new Vector3(width, 0.05f, 0.05f), pos + new Vector3(0f, 0.25f, depth/2f), _metalMat);
        CreateCube("BalconyRailBot", root, new Vector3(width, 0.05f, 0.05f), pos + new Vector3(0f, -0.2f, depth/2f), _metalMat);
        int balusters = 10;
        for (int i = 0; i < balusters; i++)
        {
            float x = -width/2f + 0.18f + i * ((width - 0.36f) / (balusters - 1));
            CreateCube("Baluster", root, new Vector3(0.03f, 0.45f, 0.03f), pos + new Vector3(x, 0.02f, depth/2f), _metalMat);
        }
    }

    private static void CreateAwning(Transform root)
    {
        GameObject awning = CreateCube("Awning", root, new Vector3(8f, 0.08f, 1.2f), new Vector3(0f, 2.65f, 4.52f), _awningMat);
        awning.transform.localRotation = Quaternion.Euler(12f, 0f, 0f);
    }

    private static void CreateShelf(Transform root, Vector3 pos)
    {
        CreateCube("ShelfSideL", root, new Vector3(0.06f, 1.8f, 0.35f), pos + new Vector3(-0.45f, 0.9f, 0f), _trimMat);
        CreateCube("ShelfSideR", root, new Vector3(0.06f, 1.8f, 0.35f), pos + new Vector3(0.45f, 0.9f, 0f), _trimMat);
        for (int i = 0; i < 4; i++)
            CreateCube("ShelfBoard", root, new Vector3(0.9f, 0.04f, 0.35f), pos + new Vector3(0f, 0.2f + i * 0.5f, 0f), _trimMat);
    }

    private static void CreateDesk(Transform root, Vector3 pos)
    {
        CreateCube("DeskTop", root, new Vector3(1.1f, 0.06f, 0.6f), pos + new Vector3(0f, 0.75f, 0f), _trimMat);
        CreateCube("DeskCabinet", root, new Vector3(0.38f, 0.72f, 0.55f), pos + new Vector3(-0.28f, 0.36f, 0f), _trimMat);
        CreateCube("DeskLeg", root, new Vector3(0.06f, 0.72f, 0.06f), pos + new Vector3(0.45f, 0.36f, 0.24f), _metalMat);
        CreateCube("DeskLeg", root, new Vector3(0.06f, 0.72f, 0.06f), pos + new Vector3(0.45f, 0.36f, -0.24f), _metalMat);
    }

    private static void CreateLamp(Transform root, Vector3 pos)
    {
        CreateCube("LampHousing", root, new Vector3(1.0f, 0.05f, 0.12f), pos, _emissiveMat);
    }

    private static void CreateLampPlane(Transform root, Vector3 pos)
    {
        CreateCube("CeilingLamp", root, new Vector3(1.6f, 0.04f, 0.18f), pos, _emissiveMat);
    }

    private static void CreateBreakablePanel(Transform root, string name, Vector3 size, Vector3 pos, Material mat, Vector3Int chunks)
    {
        GameObject panel = CreateCube(name, root, size, pos, mat);
        var breakable = panel.AddComponent<BreakableSection>();
        breakable.breakThreshold = 15f;
        breakable.chunkCount = chunks;
        breakable.chunkMass = 2.5f;
        breakable.explosionForceMultiplier = 1.2f;
        breakable.debrisLifetime = 35f;
    }

    private static void BuildLod1(Transform root)
    {
        BuildLod0(root, false);
        // remove some detail renderers to reduce cost
        foreach (Transform t in root.GetComponentsInChildren<Transform>())
        {
            if (t.name.Contains("Baluster") || t.name.Contains("Desk") || t.name.Contains("Shelf") || t.name.Contains("Lamp"))
                Object.DestroyImmediate(t.gameObject);
        }
    }

    private static void BuildLod2(Transform root)
    {
        const float width = 12f;
        const float depth = 10f;
        const float height = 10.2f;
        CreateCube("Mass", root, new Vector3(width, height, depth), new Vector3(0f, height/2f, 0f), _wallMat);
        CreateCube("OpenFrontBand", root, new Vector3(width-1f, 2.6f, 0.12f), new Vector3(0f, 1.5f, depth/2f), _trimMat);
        CreateCube("WindowBand2", root, new Vector3(width-1f, 1.7f, 0.12f), new Vector3(0f, 5.1f, depth/2f), _glassMat);
        CreateCube("WindowBand3", root, new Vector3(width-1f, 1.7f, 0.12f), new Vector3(0f, 8.4f, depth/2f), _glassMat);
    }

    private static GameObject CreateCube(string name, Transform parent, Vector3 size, Vector3 localPos, Material mat)
    {
        GameObject go = GameObject.CreatePrimitive(PrimitiveType.Cube);
        go.name = name;
        go.transform.SetParent(parent, false);
        go.transform.localPosition = localPos;
        go.transform.localScale = size;
        var mr = go.GetComponent<MeshRenderer>();
        if (mat != null) mr.sharedMaterial = mat;
        return go;
    }

    private static void CreateFolderIfMissing(string parent, string name)
    {
        string path = parent + "/" + name;
        if (!AssetDatabase.IsValidFolder(path))
            AssetDatabase.CreateFolder(parent, name);
    }
}
#endif
