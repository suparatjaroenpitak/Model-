using System.Collections.Generic;
using UnityEngine;

namespace AyutthayaSimulator.ShophouseDestructible
{
    public class BreakableSection : MonoBehaviour
    {
        [Header("Break Settings")]
        public float breakThreshold = 20f;
        public bool breakOnce = true;
        public Vector3Int chunkCount = new Vector3Int(2, 2, 1);
        public float chunkMass = 2f;
        public float explosionForceMultiplier = 1f;
        public float debrisLifetime = 45f;
        public bool startBroken = false;

        [Header("Optional")]
        public Transform intactRoot;
        public Transform chunkRoot;
        public Material overrideChunkMaterial;

        private float _damage;
        private bool _isBroken;
        private readonly List<Rigidbody> _spawnedBodies = new List<Rigidbody>();

        private void Awake()
        {
            if (intactRoot == null) intactRoot = transform;
            if (startBroken) Break(Vector3.zero, Vector3.up, 0f);
        }

        public void ApplyDamage(float amount, Vector3 hitPoint, Vector3 forceDir, float force)
        {
            if (_isBroken && breakOnce) return;
            _damage += amount;
            if (_damage >= breakThreshold)
            {
                Break(hitPoint, forceDir, force);
            }
        }

        [ContextMenu("Break Now")]
        public void BreakNow() => Break(transform.position, Vector3.up, 0f);

        public void Break(Vector3 hitPoint, Vector3 forceDir, float force)
        {
            if (_isBroken && breakOnce) return;
            _isBroken = true;

            Bounds bounds = CalculateBounds();
            HideIntact();
            SpawnChunks(bounds, hitPoint, forceDir, force * explosionForceMultiplier);
        }

        private void HideIntact()
        {
            foreach (var r in GetComponentsInChildren<Renderer>()) r.enabled = false;
            foreach (var c in GetComponentsInChildren<Collider>()) c.enabled = false;
        }

        private Bounds CalculateBounds()
        {
            var renderers = GetComponentsInChildren<Renderer>();
            if (renderers.Length == 0)
                return new Bounds(transform.position, Vector3.one);
            Bounds b = renderers[0].bounds;
            for (int i = 1; i < renderers.Length; i++) b.Encapsulate(renderers[i].bounds);
            return b;
        }

        private void SpawnChunks(Bounds worldBounds, Vector3 hitPoint, Vector3 forceDir, float force)
        {
            if (chunkRoot == null)
            {
                GameObject g = new GameObject("Chunks");
                g.transform.SetParent(transform.parent, true);
                g.transform.position = transform.position;
                g.transform.rotation = transform.rotation;
                chunkRoot = g.transform;
            }

            int cx = Mathf.Max(1, chunkCount.x);
            int cy = Mathf.Max(1, chunkCount.y);
            int cz = Mathf.Max(1, chunkCount.z);
            Vector3 size = worldBounds.size;
            Vector3 min = worldBounds.min;
            Vector3 step = new Vector3(size.x / cx, size.y / cy, size.z / cz);
            Material mat = overrideChunkMaterial;
            if (mat == null)
            {
                var r = GetComponentInChildren<Renderer>();
                if (r != null) mat = r.sharedMaterial;
            }

            for (int ix = 0; ix < cx; ix++)
            for (int iy = 0; iy < cy; iy++)
            for (int iz = 0; iz < cz; iz++)
            {
                Vector3 center = min + new Vector3((ix + 0.5f) * step.x, (iy + 0.5f) * step.y, (iz + 0.5f) * step.z);
                GameObject chunk = GameObject.CreatePrimitive(PrimitiveType.Cube);
                chunk.name = $"Chunk_{ix}_{iy}_{iz}";
                chunk.transform.SetParent(chunkRoot, true);
                chunk.transform.position = center;
                chunk.transform.localScale = step * 0.95f;
                var mr = chunk.GetComponent<MeshRenderer>();
                if (mat != null) mr.sharedMaterial = mat;
                var rb = chunk.AddComponent<Rigidbody>();
                rb.mass = chunkMass;
                _spawnedBodies.Add(rb);
                if (force > 0f)
                {
                    rb.AddExplosionForce(force, hitPoint, Mathf.Max(worldBounds.extents.magnitude, 1f), 0.2f, ForceMode.Impulse);
                    rb.AddForce(forceDir.normalized * force * 0.1f, ForceMode.Impulse);
                }
                if (debrisLifetime > 0f) Object.Destroy(chunk, debrisLifetime);
            }
        }
    }
}
