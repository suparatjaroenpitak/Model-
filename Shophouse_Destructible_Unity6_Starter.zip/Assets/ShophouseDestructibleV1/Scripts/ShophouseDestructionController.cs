using UnityEngine;

namespace AyutthayaSimulator.ShophouseDestructible
{
    public class ShophouseDestructionController : MonoBehaviour
    {
        public BreakableSection[] breakableSections;

        private void Reset()
        {
            breakableSections = GetComponentsInChildren<BreakableSection>(true);
        }

        [ContextMenu("Break Facade")]
        public void BreakFacade()
        {
            foreach (var s in breakableSections)
            {
                if (s != null) s.Break(transform.position + transform.forward * 2f, transform.forward, 10f);
            }
        }
    }
}
