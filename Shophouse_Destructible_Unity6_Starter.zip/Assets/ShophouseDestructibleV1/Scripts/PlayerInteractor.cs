using UnityEngine;
using UnityEngine.UI;

namespace AyutthayaSimulator.ShophouseDestructible
{
    public class PlayerInteractor : MonoBehaviour
    {
        public Camera targetCamera;
        public float interactDistance = 4f;
        public LayerMask mask = ~0;
        public KeyCode interactKey = KeyCode.E;
        public Text uiText;

        private void Reset()
        {
            targetCamera = Camera.main;
        }

        private void Update()
        {
            if (targetCamera == null) return;
            uiText?.gameObject.SetActive(false);

            Ray ray = new Ray(targetCamera.transform.position, targetCamera.transform.forward);
            if (Physics.Raycast(ray, out RaycastHit hit, interactDistance, mask, QueryTriggerInteraction.Ignore))
            {
                var interactable = hit.collider.GetComponentInParent<IInteractable>();
                if (interactable != null)
                {
                    if (uiText != null)
                    {
                        uiText.gameObject.SetActive(true);
                        uiText.text = interactable.GetPrompt();
                    }

                    if (Input.GetKeyDown(interactKey))
                        interactable.Interact();
                }
            }
        }
    }
}
