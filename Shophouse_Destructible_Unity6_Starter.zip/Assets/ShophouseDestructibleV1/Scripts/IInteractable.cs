namespace AyutthayaSimulator.ShophouseDestructible
{
    public interface IInteractable
    {
        void Interact();
        string GetPrompt();
    }
}
