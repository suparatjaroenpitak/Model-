using UnityEngine;

namespace AyutthayaSimulator.ShophouseDestructible
{
    public class OpenablePart : MonoBehaviour, IInteractable
    {
        public enum OpenMode { Slide, Rotate }
        public enum Axis { X, Y, Z }

        [Header("Behavior")]
        public OpenMode openMode = OpenMode.Slide;
        public Axis axis = Axis.X;
        public bool invertDirection = false;
        public float openDistance = 1.0f;
        public float openAngle = 90f;
        public float speed = 2.5f;
        public bool startsOpen = false;
        public string prompt = "E เปิด/ปิด";

        private Vector3 _closedLocalPos;
        private Quaternion _closedLocalRot;
        private Vector3 _targetPos;
        private Quaternion _targetRot;
        private bool _isOpen;

        private void Awake()
        {
            _closedLocalPos = transform.localPosition;
            _closedLocalRot = transform.localRotation;
            _isOpen = startsOpen;
            ApplyInstant(_isOpen);
        }

        private void Update()
        {
            if (openMode == OpenMode.Slide)
            {
                transform.localPosition = Vector3.Lerp(transform.localPosition, _targetPos, Time.deltaTime * speed);
            }
            else
            {
                transform.localRotation = Quaternion.Slerp(transform.localRotation, _targetRot, Time.deltaTime * speed);
            }
        }

        public void Interact()
        {
            _isOpen = !_isOpen;
            SetTarget(_isOpen);
        }

        public string GetPrompt() => prompt;

        private void ApplyInstant(bool open)
        {
            SetTarget(open);
            if (openMode == OpenMode.Slide) transform.localPosition = _targetPos;
            else transform.localRotation = _targetRot;
        }

        private void SetTarget(bool open)
        {
            float sign = invertDirection ? -1f : 1f;
            if (openMode == OpenMode.Slide)
            {
                Vector3 delta = Vector3.zero;
                if (axis == Axis.X) delta = Vector3.right * openDistance * sign;
                if (axis == Axis.Y) delta = Vector3.up * openDistance * sign;
                if (axis == Axis.Z) delta = Vector3.forward * openDistance * sign;
                _targetPos = _closedLocalPos + (open ? delta : Vector3.zero);
            }
            else
            {
                Vector3 euler = Vector3.zero;
                if (axis == Axis.X) euler = Vector3.right * openAngle * sign;
                if (axis == Axis.Y) euler = Vector3.up * openAngle * sign;
                if (axis == Axis.Z) euler = Vector3.forward * openAngle * sign;
                _targetRot = _closedLocalRot * Quaternion.Euler(open ? euler : Vector3.zero);
            }
        }
    }
}
