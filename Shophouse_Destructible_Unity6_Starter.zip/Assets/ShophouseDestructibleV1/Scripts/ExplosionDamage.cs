using UnityEngine;

namespace AyutthayaSimulator.ShophouseDestructible
{
    public class ExplosionDamage : MonoBehaviour
    {
        public float radius = 6f;
        public float damage = 50f;
        public float force = 25f;
        public LayerMask mask = ~0;
        public KeyCode testKey = KeyCode.K;

        private void Update()
        {
            if (Input.GetKeyDown(testKey))
            {
                Explode(transform.position);
            }
        }

        public void Explode(Vector3 point)
        {
            Collider[] hits = Physics.OverlapSphere(point, radius, mask, QueryTriggerInteraction.Collide);
            foreach (var hit in hits)
            {
                var breakable = hit.GetComponentInParent<BreakableSection>();
                if (breakable != null)
                {
                    Vector3 dir = (hit.bounds.center - point).normalized;
                    breakable.ApplyDamage(damage, point, dir, force);
                }
            }
        }
    }
}
