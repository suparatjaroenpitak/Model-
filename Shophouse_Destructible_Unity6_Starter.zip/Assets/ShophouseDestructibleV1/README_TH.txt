ShophouseDestructibleV1 - Unity 6 Starter Package
=================================================

แพ็กนี้เป็น "โค้ดเริ่มต้น" สำหรับสร้างอาคารพาณิชย์แบบไทย 3 ชั้นในสไตล์ AYUTTHAYA SIMULATOR
โดยยึดแนวคิด Mesh First, Texture Second

สิ่งที่มีในแพ็ก
----------------
1) Editor Generator
   - Tools/AYUTTHAYA/Generate Destructible Shophouse V1
   - สร้างโมเดลอาคาร 3 ชั้นแบบ modular
   - สร้าง LOD0 / LOD1 / LOD2
   - สร้าง material PBR เบื้องต้นจาก texture atlas ในโฟลเดอร์ Textures

2) Runtime Scripts
   - OpenablePart.cs           : เปิด/ปิด ประตูกระจก หรือประตูม้วน
   - PlayerInteractor.cs       : กด E เพื่อ interact
   - BreakableSection.cs       : ระบบผนัง/ส่วนอาคารที่พังได้
   - ExplosionDamage.cs        : ตัวอย่างการระเบิด กด K เพื่อทดสอบ
   - ShophouseDestructionController.cs : เรียกพังทั้ง façade ได้

3) Textures (Starter PBR)
   - BaseColor.png
   - Normal.png
   - Roughness.png
   - Metallic.png
   - AO.png
   - Height.png
   - Emissive.png
   - MetallicSmoothness.png

การติดตั้ง
----------
1. แตกไฟล์ zip
2. เอาโฟลเดอร์ Assets/ShophouseDestructibleV1 ไปวางในโปรเจกต์ Unity 6
3. รอ Unity import ไฟล์ให้ครบ
4. เปิดเมนู Tools > AYUTTHAYA > Generate Destructible Shophouse V1
5. จะได้ GameObject ชื่อ DestructibleShophouse_V1 ใน Scene

การใช้งานระบบเปิดประตู
----------------------
1. สร้างผู้เล่นหรือกล้อง FPS/TPS
2. ใส่ PlayerInteractor.cs กับ Player หรือ Camera
3. ลาก Camera ใส่ targetCamera
4. ถ้ามี UI Text ให้ลากใส่ uiText
5. มองไปที่ประตู แล้วกด E

การใช้งานระบบพังทลาย
----------------------
1. สร้าง GameObject ใดก็ได้ เช่น ExplosionTester
2. ใส่ ExplosionDamage.cs
3. ย้ายวัตถุไปจุดที่จะระเบิด
4. กด K เพื่อทดสอบ

หมายเหตุสำคัญ
-------------
- โค้ดชุดนี้เป็น "starter package" สำหรับเริ่มระบบ generator / destructible / openable
- Mesh เป็น procedural modular แบบ game-ready ไม่ใช่โมเดล photogrammetry หรือ sculpt AAA แท้
- PBR map ถูกสร้างเป็นชุดอ้างอิงเริ่มต้นจากภาพที่ให้มา ไม่ใช่การ bake จาก highpoly จริง
- ถ้าต้องการคุณภาพ AAA จริง ควรใช้ workflow:
  Mesh highpoly/lowpoly จริง -> UV unwrap จริง -> bake normal/AO/curvature -> author PBR ใน Substance/Blender -> import เข้า Unity
- แพ็กนี้เหมาะกับการใช้เป็นฐานแก้ไขต่อ มากกว่าจะใช้เป็น final production asset โดยไม่ปรับแต่ง

ข้อแนะนำต่อยอด
---------------
- แยก façade เป็นหลายโมดูล เพื่อทำ destruction เฉพาะจุด
- ใช้ hinge joints / fracture mesh จริง สำหรับความสมจริงมากขึ้น
- เปลี่ยน primitive mesh เป็น mesh asset จริงจาก Blender
- ทำ interior เป็น modular room kit เพิ่มเติม
- ใส่ navmesh / colliders / occlusion culling / light probes / baked GI
