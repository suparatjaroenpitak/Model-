Thai Shophouse 2F V5 — Mesh First / Unity 6

1. แตก ZIP แล้วคัดลอก Assets/ThaiShophouse2FV5 ทั้งโฟลเดอร์เข้า Assets ในโปรเจกต์ Unity (อย่าให้ Assets ซ้อนกัน)
2. ให้ Unity Import และ Compile จนเสร็จ และแก้ Compile Error จากสคริปต์อื่นก่อน
3. Tools > AYUTTHAYA > Generate Shophouse 2F V5 Clay เพื่อตรวจรูปทรง
4. เลือก root ใน Hierarchy แล้วกด F และ Tools > AYUTTHAYA > Shophouse 2F V5 Force LOD0 (Selected)
5. เมื่อพอใจรูปทรง ให้ซ่อนรถ/อาคาร Clay เดิม แล้วเลือก Tools > AYUTTHAYA > Generate Shophouse 2F V5 PBR
6. Prefab อยู่ใน Assets/GeneratedThaiShophouse2FV5/PBR/Prefabs/Shophouse2F.prefab (ชื่อ PBR อาจมีเลขต่อท้ายเมื่อสร้างซ้ำ)
7. ใช้ Unit1–Unit4 และ Street prefab แยกได้ แต่แต่ละคูหามีรายละเอียดเฉพาะตำแหน่ง ไม่เหมือนกันทุกด้าน

MeshData เป็น binary little-endian: 4 byte magic SH25, int32 vertex count, int32 index count, float32 positions (XYZ), normals (XYZ), UV (XY), int32 indices. +Y up, -Z front, 1 unit = 1 metre.
ขนาดประมาณ: อาคารกว้าง 16.8 เมตร ลึก 9.5 เมตร สูงถึงยอดจั่วประมาณ 7.8 เมตร; ทางเท้ากว้าง 17.8 เมตร
4 คูหา 2 ชั้น, 3 จั่วหน้า, 1 หน้าร้านกระจก, 3 ประตูม้วน. ใช้ Geometry จริงสำหรับราวระเบียง เสา และลอนหลังคา/กันสาด LOD0.
ภาพอ้างอิงต่างกัน: ใช้ทรง 4 คูหาจาก Wireframe และวัสดุครีมจาก Atlas; สีหลังคาแดงอิฐและขนาดเป็นค่าประมาณ
รองรับ URP/Lit และ Built-in Standard ไม่รองรับ HDRP อัตโนมัติ
BaseColor จากภาพอ้างอิงบางส่วนและพื้นผิวสร้างใหม่; Normal, Height, Roughness, Metallic เป็นการประมาณ; AO ขาว Neutral. UV ใช้ช่องวัสดุร่วมกัน ไม่ใช่ UV unwrap แบบ non-overlap. Height map ให้มาเป็นไฟล์เสริม ไม่ได้ตั้ง parallax shader
ภาพ preview เป็น software raster จาก mesh จริง, แสง diffuse เท่านั้น ไม่ใช่ Unity Render หรือ PBR render
โมเดลภายนอก; กระจกทึบ, collider อาคารเป็นกล่อง, ไม่มีภายในที่เดินได้; ผิวหลังคาบางส่วนเป็น surface ด้านเดียว; ไม่มีการรับประกัน watertight หรือไม่มีการซ้อนทุกจุด
ตรวจ binary, triangle index, normals และ UV เบื้องต้นแล้ว; ยังไม่ได้ Compile/Render ใน Unity จริง ไม่รับรอง AAA
