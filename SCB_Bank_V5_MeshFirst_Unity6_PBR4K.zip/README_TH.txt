SCB Bank V5 — Mesh First / Unity 6

ติดตั้ง: แตก ZIP แล้วนำโฟลเดอร์ Assets/SCBBankV5 ไปใส่ใน Assets ของโปรเจกต์ Unity 6 (อย่าให้ Assets ซ้อน Assets) ต้องคัดลอกทั้ง Editor, MeshData, Textures และ References ไม่ใช่เฉพาะ .cs
1. รอ Unity import และ compile เสร็จ (แก้ Console error ของสคริปต์อื่นก่อน)
2. Tools > AYUTTHAYA > Generate SCB Bank V5 Clay เพื่อดูรูปทรงก่อน
3. เลือก Root แล้ว Tools > AYUTTHAYA > SCB Bank V5 Force LOD0 (Selected) เพื่อดูรายละเอียดสูงสุด; กด F ใน Scene View
4. ปิด/ลบเฉพาะ instance ของ Clay จาก Scene แล้วเลือก Generate SCB Bank V5 PBR
5. Prefab อยู่ที่ Assets/GeneratedSCBBankV5/PBR/Prefabs/SCBBank.prefab (ชื่อโฟลเดอร์อาจมีเลขต่อท้ายเมื่อสร้างซ้ำ)
6. เลือก Root แล้ว SCB Bank V5 Restore Automatic LOD (Selected) เพื่อคืนค่า LOD
สามารถเปิด/ปิด Banner และ Trees เป็นโมดูลแยกได้ หากนำ Prefab แยกมาใช้ ให้คงตำแหน่ง local (0,0,0) เพื่อประกอบเป็นอาคารเดิม

ใช้ Unity URP/Lit หรือ Built-in Standard; ไม่รองรับ HDRP โดยตรง. C# โหลด mesh จากไฟล์ bytes (SCB5: magic 4 bytes, vertex count, index count, vertex float3, normal float3, UV float2, triangle indices int32). ไม่ต้องติดตั้ง Python/Blender.

ตัวอาคารกว้าง 12.6 ม. ลึก 11.5 ม. สูงส่วน parapet ประมาณ 11.43 ม. (ไม่รวมเสาอากาศ) เป็นสัดส่วนประมาณ ไม่ใช่ข้อมูลรังวัด. เลือกหน้าตา 365/7 จากภาพที่สาม; ต้นไม้และแผงระแนงอิงภาพอื่น. กระจกทึบ, ไม่มีภายในที่เดินได้, ต้นไม้ stylized geometry. Collider ตัวอาคารเป็นกล่องสำหรับฉากภายนอก, บันไดและทางเท้ามี collider แยก.
PBR atlas 4K สร้างจาก swatch/crop ภาพอ้างอิง 1536x1024 และสีวัสดุสังเคราะห์ มี UV ซ้ำโดยเจตนา. AO สีขาว neutral ไม่ได้ bake. Height และ Roughness แยกสำหรับแก้ไข ไม่ได้ใช้ displacement. Normal/Roughness/Metallic เป็นค่าประมาณ. Clay/Textured previews เรนเดอร์จากข้อมูล Mesh จริงด้วย software renderer; ไม่ใช่ Unity หรือ PBR lighting เต็มรูปแบบ. ยังไม่ได้ทดสอบ Unity compile/render จริง และไม่รับรองระดับ AAA.
